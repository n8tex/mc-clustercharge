#Cluster Charges in minecraft
Project inspired by a character called Fuze from Rainbow 6 Siege, who launches 5 grenades into a room through a wall. I have tried to recreate what his gadget does, but this function is still very much in it's alpha phase.
